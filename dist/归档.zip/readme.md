文档说明：
1、前端基于gulp开发，请开发修改时请参考gulpfile.js里对应的包。
2、所有js基于requirejs开发。具体使用方式请参考官方文档。
3、所有CSS基于SASS开发，修改请修改对应scss文件。